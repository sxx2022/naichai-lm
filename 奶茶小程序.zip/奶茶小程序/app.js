// app.js
App({
  onLaunch() {
    

    wx.cloud.init({
      env:'bcbdy-3gj5jsx126e4beb4'
    })

    if(wx.getStorageSync('cartList')){
      this.globalData.cartList = wx.getStorageSync('cartList')
    }
    if(wx.getStorageSync('userInfo')){
      this.globalData.userInfo = wx.getStorageSync('userInfo')
    }

    //调用云函数获取用户openid
    wx.cloud.callFunction({
      name:'shop_get_openid'
    }).then(res=>{
      console.log(res.result.openid)
      this.globalData.openid = res.result.openid
    })


  },
  getUserInfo(){
    wx.cloud.database().collection('naicha_users')
    .where({
      _openid:this.globalData.openid
    })
    .get()
    .then(res=>{
      console.log(res)
      this.globalData.userInfo = res.data[0]
      wx.setStorageSync('userInfo', res.data[0])
    })
  },
  globalData: {
    userInfo: null,

    openid:null,

    //购物车列表
    cartList:[],

    //订单列表  
    orderList:null,
    gonggao:"这是一条公告啊啊啊"

  }
})



// {
//   "pagePath": "pages/add/add",
//   "text": "发布",
//   "iconPath": "/images/add_no.png",
//   "selectedIconPath": "/images/add_yes.png"
// },


// 奶茶比咖啡多了外卖