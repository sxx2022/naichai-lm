const utils = require('../../../utils/util.js');
const app = getApp()
Page({


  data: {

  },


  onLoad(options) {
    this.getList()

  },

  getList() {
    wx.cloud.database().collection('naicha_coupon').get()
      .then(res => {
        console.log("hanhan")
        console.log(res)
        this.data.list = res.data
        for (var i in this.data.list) {
          this.data.list[i].show = true
          this.data.list[i].expiration = false

        }


        this.setStatus()
      })
  },
  setStatus() {
    var nowDate = utils.formatTime(new Date())

    var that = this
    var list = that.data.list
    wx.cloud.database().collection('naicha_couponRecord').get()
      .then(res => {
        console.log(res)
        var recordList = res.data
        for (var i in list) {
          var expirationTime = list[i].expirationTime
          var cha = new Date(nowDate) - new Date(expirationTime)
          console.log(cha)
          for (var j in recordList) {
            if (list[i]._id == recordList[j].couponId) {
              list[i].show = false
            }
            if (cha > 0) {
              list[i].expiration = true
            }
          }
        }
        console.log(list)
        this.setData({
          list: list
        })
      })
  },
  get(event) {
    console.log(event.currentTarget.dataset.id)
    let id = event.currentTarget.dataset.id
    let item = event.currentTarget.dataset.item
    var that = this
    wx.cloud.database().collection('naicha_couponRecord').add({
      data: {

        couponId: id,
        coupon: item,
        time: utils.formatTime(new Date()),
        status: "0"


      },
      success(res) {
        console.log(res)
        wx.navigateTo({
          url: '/pages/index/coupon/myCoupon/myCoupon',
          success() {
            that.getList()
            console.log('返回成功')
            wx.showToast({
              title: '领取成功',
              duration: 3000
            })
          }
        })

      }

    })
  },
  toMyCoupon() {
    wx.navigateTo({
      url: '/pages/index/coupon/myCoupon/myCoupon',
    })
  },
  kai() {
    if (!app.globalData.userInfo) {
      wx.switchTab({
        url: '/pages/me/me',
        success() {
          wx.showToast({
            title: '请登录',
            icon: 'none'
          })
        }
      })

    }



    var that = this;

    //重置 恢复
    var animation = wx.createAnimation({
      duration: 0,
    });
    animation.rotate(0).step();
    this.setData({
      cs_an: animation.export(),
    });


    //产生随机数（0-100）  判断这个数是落在哪个区间上，区间对应的就是抽到的那个物品
    var randomNum = Math.floor(101 * Math.random())
    console.log(randomNum)
    randomNum = randomNum / 100
    console.log(randomNum)

    var prizeIndex = 0
    if (randomNum >= 0 &&
      randomNum < that.data.list[0].percent) {
      prizeIndex = 1
    }
    if (randomNum >= that.data.list[0].percent &&
      randomNum < that.data.list[0].percent + that.data.list[1].percent) {
      prizeIndex = 2
    }
    if (randomNum >= that.data.list[0].percent + that.data.list[1].percent &&
      randomNum < that.data.list[0].percent + that.data.list[1].percent + that.data.list[2].percent) {
      prizeIndex = 3
    }
    if (randomNum >= that.data.list[0].percent + that.data.list[1].percent + that.data.list[2].percent &&
      randomNum < that.data.list[0].percent + that.data.list[1].percent + that.data.list[2].percent + that.data.list[3].percent) {
      prizeIndex = 4
    }
    if (randomNum >= that.data.list[0].percent + that.data.list[1].percent + that.data.list[2].percent + that.data.list[3].percent &&
      randomNum < that.data.list[0].percent + that.data.list[1].percent + that.data.list[2].percent + that.data.list[3].percent + that.data.list[4].percent) {
      prizeIndex = 5
    }
    if (randomNum >= that.data.list[0].percent + that.data.list[1].percent + that.data.list[2].percent + that.data.list[3].percent + that.data.list[4].percent &&
      randomNum < that.data.list[0].percent + that.data.list[1].percent + that.data.list[2].percent + that.data.list[3].percent + that.data.list[4].percent + that.data.list[5].percent) {
      prizeIndex = 6
    }

    console.log('prizeIndex', prizeIndex)
    var item = this.data.list[prizeIndex - 1]
    var id = this.data.list[prizeIndex - 1]._id

    wx.cloud.database().collection('naicha_couponRecord').add({
      data: {

        couponId: id,
        coupon: item,
        time: utils.formatTime(new Date()),
        status: "0"


      },
      success(res) {
        setTimeout(() => {
          wx.hideLoading({
            success: (res) => {},
          })
        }, 4000);

        //更新抽奖次数  -1
        //app.lossChouJian()

        //旋转
        var animation = wx.createAnimation({
          duration: 4000, // 转圈时间
          timingFunction: "ease",
        });
        // 转25圈+60°*(0-6)
        var randomDu = (prizeIndex - 1) * 60
        animation.rotate(360 * 15 + randomDu).step();
        that.setData({
          cs_an: animation.export()
        });
        console.log(res)
        setTimeout(() => {

          wx.showToast({
            icon: 'none',
            title: '奖品：满' + that.data.list[prizeIndex - 1].minMoney + "减" + that.data.list[prizeIndex - 1].reduceMoney,
          })
        }, 4000);


      }

    })






  },


})