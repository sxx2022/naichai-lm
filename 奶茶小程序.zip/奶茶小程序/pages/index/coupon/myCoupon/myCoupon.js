const utils = require('../../../../utils/util.js');
const app=getApp()
Page({

 
    data: {
        navbar:['未使用','已使用','已过期'],
        currentTab: 0,

    },

   
    onShow(){
    this.getType1()
    },
      //顶部tab切换
  navbarTap: function (e) {
    let index = e.currentTarget.dataset.idx;
    this.setData({
        currentTab: index
    })
    console.log("index", index)
    if(index==0){
        this.getType1()
    }
    if(index==1){
        this.getType2()
    }
    if(index==2){
        this.getType3()
    }

},
getType1(){
    var nowDate=utils.formatTime(new Date())
    wx.cloud.database().collection('naicha_couponRecord').where({
        status:"0",
        _openid:app.globalData.openid
    }).get()
    .then(res=>{
        console.log(res)
        var recordList=res.data
        var list=[]
            for(var i in recordList){
                var expirationTime=recordList[i].coupon.expirationTime
                var cha=new Date(nowDate)-new Date(expirationTime)
                console.log(cha)
              if(cha<=0){
                   list.push(recordList[i])
              }
            }
            this.setData({
                list:list
            })
        
    })
},
getType2(){
    var nowDate=utils.formatTime(new Date())
    wx.cloud.database().collection('naicha_couponRecord').where({
        status:"1",
        _openid:app.globalData.openid

    }).get()
    .then(res=>{
        console.log(res)
  
            this.setData({
                list:res.data
            })
        
    })
},
getType3(){
    var nowDate=utils.formatTime(new Date())
    wx.cloud.database().collection('naicha_couponRecord').where({
        status:"0",
        _openid:app.globalData.openid

    }).get()
    .then(res=>{
        console.log(res)
        var recordList=res.data
        var list=[]
            for(var i in recordList){
                var expirationTime=recordList[i].coupon.expirationTime
                var cha=new Date(nowDate)-new Date(expirationTime)
                console.log(cha)
              if(cha>0){
                   list.push(recordList[i])
              }
            }
            this.setData({
                list:list
            })
        
    })
},

   
})