// pages/me/edit/edit.js
const app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        nowIndex: 0,
        list1: ["男", "女"],
        localtion:"请选择位置"
    },
    lableChange: function (e) {
        var t = e.currentTarget.dataset.index;
        this.setData({
            nowIndex: t
        });
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {
        if (app.globalData.userInfo) {
            this.setData({
                avatarUrl: app.globalData.userInfo.avatarUrl,
                nickName: app.globalData.userInfo.nickName
            })
        } else {
            this.setData({
                avatarUrl: "https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0"
            })
        }
        this.getUser()
    },
    
    getUser() {

        console.log("openid=" + app.globalData.openid)
        wx.cloud.database().collection('naicha_users').where({
                _openid: app.globalData.openid
            }).get()
            .then(res => {
                console.log(res)
                this.setData({
                    user: res.data[0]
                })
                this.setData({
                    nowIndex:this.data.user.sex
                })
                this.setData({
                    localtion:this.data.user.address,

                })


            })
    },

    onChooseAvatar(e) {
        const {
            avatarUrl
        } = e.detail
        wx.cloud.uploadFile({
                cloudPath: `loginImages/${Math.random()}_${Date.now()}.png`,
                filePath: avatarUrl
            })
            .then(res => {
                console.log(res.fileID)
                this.setData({
                    avatarUrl: res.fileID
                })


            })
    },

    // 提交事件
    submitForm(event) {
        var that = this;
        if (!this.data.nickName) {
            wx.showToast({
                title: '请输入昵称',
                icon: 'none'
            })
            return;
        }
        if (!(event.detail.value.name.replace(/\s+/g, ''))) {
            wx.showToast({
                icon: 'none',
                title: '请填写姓名！',
            })
            return
        }
        if (!(event.detail.value.phone.replace(/\s+/g, ''))) {
            wx.showToast({
                icon: 'none',
                title: '请填写电话！',
            })
            return
        }
        if (event.detail.value.phone.length!=11) {
            wx.showToast({
                icon: 'none',
                title: '请填写11位的电话！',
            })
            return
        }
        if (this.data.localtion=="请选择位置") {
            wx.showToast({
                icon: 'none',
                title: '请选择位置信息！',
            })
            return
        }
        if (!(event.detail.value.address.replace(/\s+/g, ''))) {
            wx.showToast({
                icon: 'none',
                title: '请填写具体地址！',
            })
            return
        }
        var data = {};
        data.avatarUrl = this.data.avatarUrl;
        data.nickName = this.data.nickName;
        data.name = event.detail.value.name;
        data.phone = event.detail.value.phone;
        data.address = this.data.localtion;
        data.addressInfo = event.detail.value.address;

        if (app.globalData.userInfo && app.globalData.userInfo._id) {
            // 更新操作
            wx.cloud.database().collection('naicha_users')
                .doc(app.globalData.userInfo._id)
                .update({
                    data: data
                })
                .then(res => {
                    that.updateLocalUser();
                })
        } else {
            // 添加操作
            wx.cloud.database().collection('naicha_users')
                .add({
                    data: data
                }).then(res => {
                    that.updateLocalUser();
                })
        }
    },

    /**
     * 获取用户并设置回调值
     */
    updateLocalUser() {
        wx.cloud.database().collection('naicha_users')
            .where({
                _openid: app.globalData.openid
            })
            .get()
            .then(res => {
                app.globalData.userInfo = res.data[0];
                wx.setStorageSync('userInfo', res.data[0]);
                var pages = getCurrentPages(); // 当前页面
                var prevPage = pages[pages.length - 2]; // 上个页面
                // 直接给上一个页面赋值
                prevPage.setData({
                    userInfo: res.data[0]
                });
                wx.navigateBack({
                    success(){
                        wx.showToast({
                          title: '更新成功',
                        })
                    }
                })
            })
    },
    
    chooseAddress() {
        var that = this;
        wx.chooseLocation({
            success(res) {
                console.log(res)

                that.setData({
                    localtion: res.address + res.name,
                    addresssInfo: res
                })

                if (res.address == "") {
                    that.setData({
                        localtion: "请选择位置"
                    })
                }
            }
        })
    },
    
})